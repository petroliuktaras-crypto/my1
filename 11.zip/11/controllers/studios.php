<?php

$sort = $_GET['sort'] ?? 'new';

$studios = getStudiosWithCount($sort);

render('studios', [
    'studios' => $studios,
    'sort'    => $sort
]);
