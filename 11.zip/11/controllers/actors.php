<?php

$letter = $parts[1] ?? null;
$gender = $_GET['gender'] ?? null;
$page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;

$perPage = ACTORS_PER_PAGE;
$offset  = ($page - 1) * $perPage;

// валідація
if ($letter !== null && !preg_match('/^[A-Z]$/', $letter)) {
    abort404();
}

if ($gender !== null && !in_array($gender, ['male', 'female'], true)) {
    abort404();
}

$actors = getActorsList($letter, $gender, $perPage, $offset);
$total  = getActorsTotal($letter, $gender);
$pages  = (int)ceil($total / $perPage);

if ($page > 1 && $page > $pages) {
    abort404();
}

render('actors', [
    'actors' => $actors,
    'letter' => $letter,
    'gender' => $gender,
    'page'   => $page,
    'pages'  => $pages,
]);
