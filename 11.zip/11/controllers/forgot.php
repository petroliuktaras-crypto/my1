<?php
session_start();

if (isset($_SESSION['user_id'])) {
    // Якщо користувач вже увійшов, перенаправляємо на сторінку профілю
    header('Location: /profile');
    exit();
}

$error = null;
$success = false;



// Перевірка, чи була надіслана форма
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Отримуємо введений email і captcha
    $email = $_POST['email'];
    $captcha = $_POST['captcha'];

    // Перевірка, чи введена CAPTCHA
    if ($captcha != $_SESSION['captcha_answer']) {
        $error = "Невірна відповідь на капчу!";
    }
    // Перевірка, чи введено email
    elseif (empty($email)) {
        $error = 'Введіть email';
    } else {
        // Використовуємо функцію перевірки користувача
        if (userExists($email, $email)) {
            // Якщо користувач знайдений, генеруємо токен для відновлення паролю
            $token = bin2hex(random_bytes(16));  // Генерація токена

            // Зберігаємо токен у базі даних або сесії для подальшої перевірки
            // Збереження токена в базі даних
            $stmt = $db->prepare("UPDATE users SET reset_token = ? WHERE email = ?");
            $stmt->execute([$token, $email]);

            // Відправляємо email з посиланням для скидання паролю
            $emailSent = sendResetPasswordEmail($email, $token);  // Викликаємо функцію для відправки email

            if ($emailSent === true) {
                $success = true;  // Якщо лист відправлений, виводимо повідомлення про успіх
            } else {
                $error = 'Не вдалося відправити лист. Спробуйте ще раз пізніше.';
            }
        } else {
            $error = 'Користувача з таким email не знайдено!';
        }
    }
}

// Генерація капчи
$a = rand(1, 9);
$b = rand(1, 9);

// Збереження правильної відповіді на капчу в сесії
$_SESSION['captcha_answer'] = $a + $b;

// Передача змінних до шаблону для рендерингу
render('forgot', [
    'captcha_a' => $a,
    'captcha_b' => $b,
    'error'     => $error ?? null,
    'success'   => $success
]);

// Очищення повідомлення після рендерингу
unset($_SESSION['success_message']);
?>
