<?php
http_response_code(404);
render('404');
exit;