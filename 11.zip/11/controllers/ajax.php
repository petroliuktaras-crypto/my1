<?php
// controllers/ajax.php

$action = $_GET['slug'] ?? null; // router вже підставляє slug з URL

switch ($action) {

    case 'video-reaction':
        require ROOT.'/controllers/ajax/video-reaction.php';
        break;

    default:
        abort404();
}
