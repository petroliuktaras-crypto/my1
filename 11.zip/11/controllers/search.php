<?php

$query = isset($_GET['query']) ? trim($_GET['query']) : '';
$isAjax = (isset($_GET['ajax']) && $_GET['ajax'] === 'true');

// Для AJAX: якщо запит короткий — повертаємо порожній масив (JSON), без редіректа
if ($isAjax) {
    if ($query === '' || mb_strlen($query, 'UTF-8') < 2) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $results = searchDatabase($query);

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($results, JSON_UNESCAPED_UNICODE);
    exit;
}

// Для звичайної сторінки: правила жорсткіші
if ($query === '' || mb_strlen($query, 'UTF-8') < 3) {
    header('Location: /');
    exit;
}

// Пошук
$results = searchDatabase($query);

// Підрахунок типів
$videoCount  = 0;
$actorCount  = 0;
$studioCount = 0;

foreach ($results as $result) {
    if (($result['type'] ?? '') === 'video') $videoCount++;
    elseif (($result['type'] ?? '') === 'actor') $actorCount++;
    elseif (($result['type'] ?? '') === 'studio') $studioCount++;
}

// Рендеримо сторінку
render('search_results', [
    'query'       => $query,
    'results'     => $results,
    'videoCount'  => $videoCount,
    'actorCount'  => $actorCount,
    'studioCount' => $studioCount,
]);
