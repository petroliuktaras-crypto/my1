<?php
// controllers/actor.php

if (empty($slug)) {
    abort404();
}

// отримуємо актора
$actor = getActorBySlug($slug);
if (!$actor) {
    abort404();
}

// відео цього актора
$videos = getActorVideos($actor['id']);

// рендер
render('actor', [
    'actor'  => $actor,
    'videos' => $videos
]);
