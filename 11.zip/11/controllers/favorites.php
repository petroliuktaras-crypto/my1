<?php

if (empty($_SESSION['user_id'])) {
    header('Location: /login?redirect=favorites');
    exit;
}

$userId = (int)$_SESSION['user_id'];

$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 24;
$offset = ($page - 1) * $limit;

$total  = getUserFavoritesCount($userId);
$videos = getUserFavoriteVideos($userId, $limit, $offset);

render('favorites', [
    'videos' => $videos,
    'total'  => $total,
    'page'   => $page,
    'limit'  => $limit
]);
