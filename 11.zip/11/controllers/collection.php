<?php

// slug вже з router
if (!$slug) abort404();

// колекція
$collection = getCollectionBySlug($slug);
if (!$collection) abort404();

// пагінація
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = PER_PAGE;
$offset   = ($page - 1) * $perPage;

// відео колекції
$videos = getCollectionVideos(
    $collection['id'],
    $perPage,
    $offset
);

// кількість
$totalVideos = getCollectionVideosCount($collection['id']);
$totalPages  = (int)ceil($totalVideos / $perPage);

render('collection', [
    'collection'   => $collection,
    'videos'       => $videos,
    'page'         => $page,
    'totalPages'   => $totalPages,
    'totalVideos'  => $totalVideos
]);
