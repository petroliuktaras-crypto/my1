<?php


render('rules');
