<?php
// controllers/categories.php

$categories = getCategoriesWithCount();

render('categories', [
    'categories' => $categories
]);
