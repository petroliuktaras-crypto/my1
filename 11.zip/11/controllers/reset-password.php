<?php
// Підключення сесії
session_start();

if (isset($_SESSION['user_id'])) {
    // Якщо користувач вже увійшов, перенаправляємо на сторінку профілю
    header('Location: /profile');
    exit();
}

// Перевірка наявності токену в URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $error = null;
    $success = null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Отримуємо дані з форми
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        $captcha = $_POST['captcha'];

        // Перевірка, чи співпадає введена капча
        if ($captcha != $_SESSION['captcha_answer']) {
            $error = "Невірна відповідь на капчу!";
        }
        // Перевірка чи паролі співпадають
        elseif ($new_password !== $confirm_password) {
            $error = "Паролі не співпадають!";
        }
        // Перевірка паролю на складність
        elseif (!preg_match('/[a-z]/', $new_password) || !preg_match('/[A-Z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
            $error = "Пароль має містити хоча б одну малу літеру, одну велику літеру та одну цифру.";
        } else {
            // Перевірка токену в базі даних
            $stmt = $db->prepare("SELECT * FROM users WHERE reset_token = ?");
            $stmt->execute([$token]);
            $user = $stmt->fetch();

            if ($user) {
                // Хешуємо новий пароль
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Оновлюємо пароль та очищуємо токен
                $stmt = $db->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?");
                if ($stmt->execute([$hashed_password, $token])) {
                    $_SESSION['success_message'] = 'Пароль успішно змінено! Перейдіть до входу.';
                    // Перенаправляємо через 10 секунд
                    echo "<script>
                        setTimeout(function() {
                            window.location.href = '/login'; // Перенаправлення на сторінку входу
                        }, 10000); // Затримка 10 секунд
                    </script>";
                } else {
                    $error = 'Помилка при зміні паролю.';
                }
            } else {
                $error = 'Невірний токен.';
            }
        }
    }

    // Генерація капчи
    $a = rand(1, 9);
    $b = rand(1, 9);
    $_SESSION['captcha_answer'] = $a + $b;

    // Передаємо дані для рендерингу
    render('reset-password', [
        'captcha_a' => $a,
        'captcha_b' => $b,
        'error' => $error ?? null,
        'success' => $_SESSION['success_message'] ?? null,
        'token' => $token
    ]);

    // Очищаємо повідомлення після того, як воно передано в шаблон
    unset($_SESSION['success_message']);
} else {
    // Якщо токен не передано
    header('Location: /');
    exit();
}
?>
