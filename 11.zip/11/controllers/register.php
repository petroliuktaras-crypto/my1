<?php
session_start();

if (isset($_SESSION['user_id'])) {
    // Якщо користувач вже увійшов, перенаправляємо на сторінку профілю
    header('Location: /profile');
    exit();
}

// Перевірка, чи форма була відправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Отримуємо дані з форми
    $email = $_POST['email'];
    $nickname = $_POST['nickname'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $captcha = $_POST['captcha'];
    $accept_terms = isset($_POST['accept_terms']); // Перевіряємо, чи був поставлений чекбокс

    // Перевіряємо, чи співпадає введена капча
    if ($captcha != $_SESSION['captcha_answer']) {
        $error = "Невірна відповідь на капчу!";
    }
    // Перевірка чи паролі співпадають
    elseif ($password !== $confirm_password) {
        $error = "Паролі не співпадають!";
    }
    // Перевірка, чи користувач погодився з правилами
    elseif (!$accept_terms) {
        $error = "Ви повинні погодитись з правилами користування!";
    }
    // Перевірка паролю на складність
    elseif (!preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = "Пароль має містити хоча б одну малу літеру, одну велику літеру та одну цифру.";
    } else {
        // Викликаємо функцію реєстрації
        $isRegistered = registerUser($email, $nickname, $password);
        
        // Якщо реєстрація була успішною
        if ($isRegistered) {
            $_SESSION['success_message'] = 'Реєстрація успішно виконана! Дякую Вам за реєстрування на нашому сайті';
            // Перенаправляємо через 10 секунд
            echo "<script>
                setTimeout(function() {
                    window.location.href = '/login'; // Перенаправлення на сторінку входу
                }, 10000); // Затримка 10 секунд
            </script>";
        } else {
            $error = "Користувач з таким імейлом або нікнеймом вже існує!";
        }
    }
}

// Генерація капчи
$a = rand(1, 9);
$b = rand(1, 9);

// Збереження правильної відповіді на капчу в сесії
$_SESSION['captcha_answer'] = $a + $b;

// Передаємо дані для рендерингу
render('register', [
    'captcha_a' => $a,
    'captcha_b' => $b,
    'error' => $error ?? null,
    'success' => $_SESSION['success_message'] ?? null
]);

// Очищаємо повідомлення після того, як воно передано в шаблон
unset($_SESSION['success_message']);
?>
