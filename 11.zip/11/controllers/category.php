<?php

// slug з router
if (!$slug) abort404();

// категорія
$category = getCategoryBySlug($slug);
if (!$category) abort404();

// пагінація
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = PER_PAGE; // з config.php
$offset   = ($page - 1) * $perPage;


// відео категорії
$videos = getCategoryVideos(
    $category['id'],
    $perPage,
    $offset
);

// кількість
$totalVideos = getCategoryVideosCount($category['id']);
$totalPages  = (int)ceil($totalVideos / $perPage);

render('category', [
    'category'     => $category,
    'videos'       => $videos,
    'page'         => $page,
    'totalPages'   => $totalPages,
    'totalVideos'  => $totalVideos
]);
