<?php

$sort = $_GET['sort'] ?? 'new';

$collections = getCollectionsWithCount($sort);

render('collections', [
    'collections' => $collections,
    'sort'        => $sort
]);