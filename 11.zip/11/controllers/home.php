<?php

$current = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

$type = $_GET['filter'] ?? 'new';

switch ($type) {
    case 'views':
        $videos = getPopularVideos();
        break;

    case 'new':
    default:
        $videos = getLatestVideos();
}

render('home', compact('videos','type'));
