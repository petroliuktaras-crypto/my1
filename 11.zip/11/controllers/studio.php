<?php

if (!$slug) abort404();

$studio = getStudioBySlug($slug);
if (!$studio) abort404();

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = PER_PAGE;
$offset  = ($page - 1) * $perPage;

$videos = getStudioVideos($studio['id'], $perPage, $offset);

$totalVideos = getStudioVideosCount($studio['id']);
$totalPages  = (int)ceil($totalVideos / $perPage);

render('studio', [
    'studio'      => $studio,
    'videos'      => $videos,
    'page'        => $page,
    'totalPages'  => $totalPages,
    'totalVideos' => $totalVideos
]);
