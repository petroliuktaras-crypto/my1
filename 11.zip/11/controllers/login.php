<?php
// controllers/login.php

$isModal = (isset($_GET['modal']) && $_GET['modal'] == '1');

// Якщо вже залогінений (у тебе через cookie session_id + sessions table)
if (getCurrentUserId() > 0) {
    if ($isModal) {
        // в iframe: просто оновлюємо батька
        echo '<!doctype html><html><head><meta charset="utf-8"></head><body>
        <script>
          try { window.parent.location.reload(); }
          catch(e){ window.location.href="/profile"; }
        </script>
        </body></html>';
        exit;
    }

    header('Location: /profile');
    exit;
}

$error = null;
$greeting = '';

// POST логін
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Введіть email та пароль';
    } else {
        if (login($email, $password)) {
            // ✅ login() має створити cookie session_id і запис у sessions
            if ($isModal) {
                echo '<!doctype html><html><head><meta charset="utf-8"></head><body>
                <script>
                  try { window.parent.location.reload(); }
                  catch(e){ window.location.href="/profile"; }
                </script>
                </body></html>';
                exit;
            }

            header('Location: /profile');
            exit;
        } else {
            $error = 'Невірний логін або пароль';
        }
    }
}

// greeting не потрібен, бо якщо вже залогінений — ми редіректимо/оновлюємо
$greeting = '';

// Рендер
if ($isModal) {
    // iframe-версія (без header/footer)
    require ROOT.'/templates/'.TEMPLATE.'/login-modal.php';
    exit;
}

// звичайна сторінка
render('login', [
    'greeting' => $greeting,
    'error' => $error
]);
