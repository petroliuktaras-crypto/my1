<?php

// Початок сесії
session_start();

// Підключаємо файл функцій, щоб використовувати checkSession()
require_once __DIR__ . '/../engine/functions.php';


// Викликаємо функцію для перевірки сесії
checkSession();

// Перевірка наявності користувача в сесії
if (!isset($_SESSION['user_id'])) {
    header('Location: /login');
    exit();
}

// При натисканні на кнопку "Вийти"
if (isset($_POST['logout'])) {
    logout(); // Викликаємо функцію для виходу
}

// Виводимо сторінку профілю
render('profile', [
    'user' => $_SESSION['login'] 
]);
