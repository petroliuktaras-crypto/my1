<?php


// controllers/video.php

// 1️⃣ отримуємо slug з URL
if (empty($slug)) {
    abort404();
}

$video = getVideoBySlug($slug);
if (!$video) {
    abort404();
}

$counts = getVideoLikeCounts((int)$video['id']);

$likeCount = $counts['likes'];
$dislikeCount = $counts['dislikes'];
$totalVotes = $likeCount + $dislikeCount;

addVideoView((int)$video['id']);
$viewsCount = getVideoViewsCount((int)$video['id']);



$videosWithActors = getVideosWithSameActors($video['id'], 4);

$screenshots = getVideoScreenshots($video['id']);



// 3️⃣ АКТОРИ
$actors = getVideoActors($video['id']);

// 4️⃣ СТУДІЇ
$studios = getVideoStudios($video['id']);

// 5️⃣ КОЛЕКЦІЇ
$collections = getVideoCollections($video['id']);

// 6️⃣ КОМЕНТАРІ
$comments = getVideoComments($video['id']);

$category = getVideoCategory($db, (int)$video['id']);

// 7️⃣ РЕКОМЕНДОВАНІ ВІДЕО
$recommended = getRecommendedVideos($video['id'], 6);

$token = generatePlayerToken($video['id'], 60);

// 8️⃣ РЕНДЕР ШАБЛОНУ
render('video', [
    'video'        => $video,
    'rating'       => $rating,
    'votes'        => $votes,
    'likeCount' => $likeCount,
    'dislikeCount' => $dislikeCount,
	'counts' => $counts,
	'totalVotes' => $totalVotes,
    'viewsCount' => $viewsCount,
    'actors'       => $actors,
	'category'       => $category,
    'studios'      => $studios,
    'collections'  => $collections,
    'screenshots'  => $screenshots,
    'comments'     => $comments,
    'recommended'  => $recommended,
    'videosWithActors'  => $videosWithActors,
    'token'        => $token
]);