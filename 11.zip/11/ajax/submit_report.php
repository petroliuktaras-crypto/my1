<?php
// Встановлюємо шлях до файлу логів
$logFile = __DIR__ . '/logs.txt';

// Функція для логування повідомлень
function logMessage($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s'); // Часова мітка
    $logMessage = "[$timestamp] $message\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND); // Запис в файл
}


// Параметри підключення до БД
$host = 'fi606084.mysql.tools'; // хост (можна змінити на ваш сервер БД)
$dbname = 'fi606084_taraska'; // ім'я вашої бази даних
$username = 'fi606084_taraska'; // ваш логін до БД
$password = '~r7)aJ2tE7'; // ваш пароль до БД


// Перевірка на POST-запит
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    logMessage("Запит типу POST");

    // Отримуємо значення з форми
    $reason = trim($_POST['reason']);
    $message = trim($_POST['message']);

    // Перевірка на порожні поля
    if (empty($reason) || empty($message)) {
        logMessage("Помилка: Порожні поля. Не вдалося відправити скаргу.");
        echo json_encode(['success' => false, 'message' => 'Будь ласка, виберіть причину та введіть текст.']);
        exit;
    }

    try {
        // Підключення до БД (PDO)
        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
            $username,
            $password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );

        // Логування підключення
        logMessage("Підключення до БД успішне.");

        // SQL-запит для вставки скарги
        $query = "INSERT INTO reports (reason, message) VALUES (:reason, :message)";
        $stmt = $pdo->prepare($query);

        // Прив'язка параметрів
        $stmt->bindParam(':reason', $reason);
        $stmt->bindParam(':message', $message);

        // Виконання запиту
        $executeResult = $stmt->execute();

        // Логування результату виконання запиту
        logMessage("Результат виконання запиту: " . var_export($executeResult, true));

        // Перевірка кількості змінених рядків
        $rowsInserted = $stmt->rowCount();
        logMessage("Рядків додано: $rowsInserted");

        if ($executeResult && $rowsInserted > 0) {
            logMessage("Скарга надіслана успішно.");
            echo json_encode(['success' => true, 'message' => 'Ваша скарга була надіслана успішно!']);
        } else {
            // Якщо запит виконано, але рядки не були додані
            logMessage("Запит виконано, але жоден рядок не був доданий.");
            echo json_encode(['success' => false, 'message' => 'Не вдалося відправити скаргу. Спробуйте ще раз.']);
        }

    } catch (PDOException $e) {
        // Логування помилки при виконанні запиту
        logMessage("Помилка при виконанні запиту: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Сталася помилка при відправці скарги: ' . $e->getMessage()]);
    }

} else {
    // Логування для запитів, що не є POST
    logMessage("Запит не POST. Тип запиту: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode(['success' => false, 'message' => 'Невірний запит.']);
}
?>