-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: fi606084.mysql.ukraine.com.ua:3306
-- Время создания: Фев 03 2026 г., 20:06
-- Версия сервера: 8.4.6-6
-- Версия PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fi606084_taraska`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actors`
--

CREATE TABLE `actors` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `bio` text,
  `birthdate` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `actors`
--

INSERT INTO `actors` (`id`, `name`, `gender`, `slug`, `photo`, `bio`, `birthdate`, `created_at`) VALUES
(1, 'John Doe', 'male', 'john-doe', '/uploads/actors/actor1.jpg', 'Бенисио дель Торо родился 19 февраля 1967 года в городе Сан-Хермане, в семье адвоката Густаво Адольфо дель Торо Бермудеса и Фаусты Санчес Ривера. У актёра есть брат по имени Густаво, он старше его на два года и в настоящее время работает детским онкологом на Манхэттене. У Бенисио есть каталонские корни со стороны отца и баскские со стороны матери. Также, по словам актёра, у него есть корни коренных американцев. У Бенисио есть родственные связи с пуэрто-риканским баскетболистом Карлосом Арройо, поп-певицей Ребекой Поус дель Торо и певцом Элесо дель Торо.\n\nВ детстве актёра называли «Худышка Бенни» и «Бено», он воспитывался католиком и учился в католической школе. Когда Бенисио было 9 лет, его мать умерла от последствий гепатита. В 12 отец отправил сына к родственникам в США в небольшой город Мерсербург в Пенсильвании, где Бенисио определили в местную школу-интернат. После школы по настоянию отца Бенисио дель Торо поступил в Университет Калифорнии в Сан-Диего, где изучал бизнес. ', '2026-01-14', '2026-01-17 21:34:45'),
(2, 'Jane Smith', 'male', 'jane-smith', '/uploads/actors/actor2.jpg', 'Another test actor', NULL, '2026-01-17 21:34:45'),
(3, 'Alex Brown', 'female', 'alex-brown', '/uploads/actors/actor5.jpg', 'Famous test actor', NULL, '2026-01-17 21:34:45');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`, `description`, `created_at`) VALUES
(1, 'Action', 'action', 'Action movies', '2026-01-17 21:34:33'),
(2, 'Drama', 'drama', 'Drama movies', '2026-01-17 21:34:33'),
(3, 'Comedy', 'comedy', 'Comedy movies', '2026-01-17 21:34:33');

-- --------------------------------------------------------

--
-- Структура таблицы `category_video`
--

CREATE TABLE `category_video` (
  `category_id` int UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `category_video`
--

INSERT INTO `category_video` (`category_id`, `video_id`) VALUES
(1, 6),
(1, 7),
(1, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `collections`
--

CREATE TABLE `collections` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `poster` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `collections`
--

INSERT INTO `collections` (`id`, `title`, `slug`, `description`, `poster`, `created_at`) VALUES
(1, 'Top Movies', 'top-movies', 'Best test movies collection', '/uploads/collections/test1.jpg', '2026-01-17 21:36:50'),
(2, 'Top Movies2', 'top-movies2', 'Best test movies collection', '/uploads/collections/test2.jpg', '2026-01-17 21:36:50'),
(3, 'Top Movies3', 'top-movies3', 'Best test movies collection', '/uploads/collections/test1.jpg', '2026-01-17 21:36:50');

-- --------------------------------------------------------

--
-- Структура таблицы `collection_videos`
--

CREATE TABLE `collection_videos` (
  `collection_id` int UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL,
  `sort` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `collection_videos`
--

INSERT INTO `collection_videos` (`collection_id`, `video_id`, `sort`) VALUES
(1, 8, 0),
(2, 7, 0),
(2, 8, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `parent_id` int UNSIGNED DEFAULT NULL,
  `message` text NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `video_id`, `user_id`, `parent_id`, `message`, `status`, `created_at`) VALUES
(2, 8, 1, NULL, 'This is a test comment', 1, '2026-01-17 23:45:52');

-- --------------------------------------------------------

--
-- Структура таблицы `reports`
--

CREATE TABLE `reports` (
  `id` int NOT NULL,
  `reason` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `reports`
--

INSERT INTO `reports` (`id`, `reason`, `message`, `created_at`) VALUES
(1, 'Неправильний контент', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:06:35'),
(2, 'Неправильний контент', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:07:57'),
(3, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:42'),
(4, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:42'),
(5, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(6, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(7, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(8, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(9, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(10, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(11, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:43'),
(12, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:44'),
(13, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:14:44'),
(14, 'Неправильний контент', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer', '2026-01-23 13:31:15'),
(15, 'Порушення правил', 'sdfsdfsfsdffsfsdfs e rgererer frerfererer  dsfds', '2026-01-23 13:36:07'),
(16, 'Інші причини', 'sdfsdfsfsфівфівфі frerfererer  dsfds', '2026-01-23 13:38:52'),
(17, 'Неправильний контент', 'sdfsdfsfsфівфівфі frerвмівмівмівмівмівмererer  dsfds', '2026-01-23 13:40:20'),
(18, 'Неправильний контент', 'sdfsdfsfsфівфівфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:41:28'),
(19, 'Порушення правил', 'sdfsdfsfsфівфівфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:42:40'),
(20, 'Неправильний контент', 'sdfsdfsfsфівфівфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:44:06'),
(21, 'Порушення правил', 'sdfsdfsfsфівфіваіваіваівавфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:45:52'),
(22, 'Неправильний контент', 'sdfsdfsfsфівфіваіваіваівавфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:48:45'),
(23, 'Порушення правил', 'sdfsdfsfsфівфіваіваіваівавфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:51:52'),
(24, 'Порушення правил', 'sdfsdfsfsфівфxcxcіваіваіваівавфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:53:44'),
(25, 'Порушення правил', 'sdfsdfsfsфівфxcxcіваіваіваівавфі frerвмівмівмівмівмівмererer  смчсчсdsfds', '2026-01-23 13:56:33'),
(26, 'Неправильний контент', 'івааіва ів аіваів', '2026-01-23 13:59:31'),
(27, 'Неправильний контент', 'івфівфівфівфі вфівфівфіфі', '2026-01-23 14:01:37'),
(28, 'Інші причини', 'віаіваіваіваіваві', '2026-01-23 14:01:49'),
(29, 'Порушення правил', 'фівфі вфівфів фівфів фі', '2026-01-23 14:03:06'),
(30, 'Порушення правил', 'іваіва іваів  аіваіваіваів іввфівфі чясяч', '2026-01-23 14:07:59'),
(31, 'Порушення правил', 'йцукецуеукецукеук', '2026-01-23 14:17:27'),
(32, 'Неправильний контент', 'івааіваів', '2026-01-23 14:48:11'),
(33, 'Неправильний контент', 'ghjghjghjghjgh', '2026-01-23 15:28:25'),
(34, 'Неправильний контент', 'іваіваіваів', '2026-01-26 14:08:45'),
(35, 'Неправильний контент', 'ваіваіваіваіваіва', '2026-01-26 14:08:59'),
(36, 'Неправильний контент', 'івівівівів', '2026-01-28 08:03:42'),
(37, 'Порушення правил', 'dfssd', '2026-01-28 08:25:29'),
(38, 'Порушення правил', 'чсчс', '2026-01-28 14:40:59'),
(39, 'Порушення правил', 'dfsdfsd', '2026-02-02 13:20:50');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `session_id`, `created_at`) VALUES
(11, 1, 'bd652c8324e1781064b45eb76d962d07', '2026-01-24 13:56:00'),
(12, 1, '2ec4e6a704820c30f7a42df930744fbe', '2026-01-24 13:57:34'),
(13, 1, '7f92d636e98cb32cb7724ff29abb186d', '2026-01-24 13:58:09'),
(16, 1, '502c0fa4a09e84e01c505dae699c08d0', '2026-01-24 14:34:32'),
(25, 23, 'e37cfb7cfef7c0a0d4cdd278c3dbc756', '2026-01-27 16:42:08'),
(39, 2, '87cd8f7eebb936cfcb7f66deea321c14', '2026-02-03 18:04:45');

-- --------------------------------------------------------

--
-- Структура таблицы `studios`
--

CREATE TABLE `studios` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `poster` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `studios`
--

INSERT INTO `studios` (`id`, `title`, `slug`, `poster`, `created_at`) VALUES
(1, 'Test Studio One', 'test-studio-one', '/uploads/studios/studio1.jpg', '2026-01-18 15:03:28'),
(2, 'Test Studio Two', 'test-studio-two', '/uploads/studios/studio2.jpg', '2026-01-18 15:03:28');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('user','admin','moderator') DEFAULT 'user',
  `status` tinyint DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `reset_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `password`, `avatar`, `role`, `status`, `created_at`, `reset_token`) VALUES
(1, 'admin', 'admin@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'admin', 1, '2026-01-17 21:37:32', NULL),
(2, 'dolboyob', 'user@gmail.com', '$2y$10$FFNKgcg53sPWNVE88hizxeI6x798umwlOTaQND7zxEfWpPm5t1Ghy', NULL, 'user', 1, '2026-01-25 11:43:27', NULL),
(3, 'dolboyob1', 'aaaaa@gmail.com', '$2y$10$bSJX.UP.8/7l5IKt3gFX3OkJEdfNPmn7lWlpKIe1.ictMFRHM12PW', NULL, 'user', 1, '2026-01-25 11:54:15', NULL),
(4, 'dolboyob11', 'user1@gmail.com', '$2y$10$QaaJAiyxuAQ0tMA.hw3j3uUxSM0RgF5Q6YZMpkcy8W0JZSqwInbKi', NULL, 'user', 1, '2026-01-25 11:57:50', NULL),
(5, 'dolboyob121', 'user1111@gmail.com', '$2y$10$F3wnvlQDrm4re56VoyFCpunhbB5pA8JtdJTOUOB.iwUDFhOXQW/yW', NULL, 'user', 1, '2026-01-25 12:07:11', NULL),
(6, 'pata1', 'admin5@test.com', '$2y$10$txDyNHmUntYBLoYwwPoRJuXWZGIkKIEOO2cyplbQtLHl7NQWB25YW', NULL, 'user', 1, '2026-01-25 12:20:06', NULL),
(7, 'asaaaaaaaa', 'asdasdasdd@gmail.com', '$2y$10$UnaY.INX6E33.kvCrgNJpuDxfZh8YutcLNswvwggj1gt2tiwSArB.', NULL, 'user', 1, '2026-01-25 12:34:16', NULL),
(8, 'qwerty', 'admi444n@test.com', '$2y$10$GcF687Q2x6xJNZ1K53H9r.qTV6BfF.ArvmVyWqeqPXuC5Tuh8kYBe', NULL, 'user', 1, '2026-01-25 12:35:29', NULL),
(9, 'pata1444444', 'admi4344n@test.com', '$2y$10$6JQjhF9rAQFQCmd9pRX4.Orh4IvJjZtgqfty/62.Du3S1FBivxtaO', NULL, 'user', 1, '2026-01-25 12:38:39', NULL),
(10, 'asaaaaaaaa3', 'admi4434n@test.com', '$2y$10$UwX1IquE23.rAecL.VrKBeyAieW9il1oRgr6W7XBZfW1tlMqtdqh2', NULL, 'user', 1, '2026-01-25 12:39:17', NULL),
(11, 'asaaaaaaaa333334', 'admin223333@test.com', '$2y$10$r37iTv2GIxZ54BtYTAIcfemTX3PtjaeEwRXYMq/N2xJB8ZFP0nB/C', NULL, 'user', 1, '2026-01-25 12:41:20', NULL),
(12, 'asaaaaaaaa454545454', 'admi4455564n@test.com', '$2y$10$wj6jJsbisuEuEMeW9dLw6OzJQKqzhH.ex2wFrget8k5WpPPTOHJnC', NULL, 'user', 1, '2026-01-25 12:43:41', NULL),
(13, 'asdfdsfsdfsdfsdf', 'admi4244n@test.com', '$2y$10$UrLjsbrhV4SzpDtkZcRbGun/Cd13XfaShk57h0bo6.jTG2kFZ2EGC', NULL, 'user', 1, '2026-01-25 15:16:18', NULL),
(14, 'dfgsdfgdfggdfg', 'asdasddddasdd@gmail.com', '$2y$10$NvW58dR8KeTeseDAw56ALekDV8oQydcwgo4tUKAXxOwje/Tlbq.yS', NULL, 'user', 1, '2026-01-25 15:19:09', NULL),
(15, 'dfgsdfgdfggdfg1111', 'user17676@gmail.com', '$2y$10$/PW5qiwcTI04.SYFzyUUFeO/WbqbIpMgzfrJ1jUiIzf6q1.T4uqPa', NULL, 'user', 1, '2026-01-25 15:20:44', NULL),
(16, 'dfsdfsdfsdfsdf', 'admin345534534@test.com', '$2y$10$66EHcZDJcR9ph/bKP490YeCyuqoNLO5vck8QRUWBp4gEKQysDhwrq', NULL, 'user', 1, '2026-01-25 15:30:44', NULL),
(17, 'erhhfghghjhgj', 'admi44345453453453454n@test.com', '$2y$10$TRyf/jRxn38Ka7s.PrCOze7dMInyUmrxPvvE5Z5GzbgjVQbGvFmT6', NULL, 'user', 1, '2026-01-25 15:32:07', NULL),
(18, 'dfghdfgdfgdfgdfgdf', 'admi43453444n@test.com', '$2y$10$BsCcRAAgB347nbL0CyePDOxQabp0UNWxyH8jWbCPekhp2ONbUs7FW', NULL, 'user', 1, '2026-01-25 15:33:59', NULL),
(19, 'fgfdfgsdfsdf', 'admi43455664553444n@test.com', '$2y$10$t15csXbEOHaLko3wY4dcmuZNhmNFoe6hE6.6yjE91fZFsxZfqRuKO', NULL, 'user', 1, '2026-01-25 15:41:13', NULL),
(20, 'ghfftftyftyfty', 'petrolyuk.taras@ukr.net', '$2y$10$D9RIHoRSUp.SbJcEikWBIOw9/HNJNruzsedoWYM0QY/oXGaguERZ.', NULL, 'user', 1, '2026-01-25 16:36:18', '0cfb95cb89eedd3f82a9f88849909c4f'),
(21, 'fdggdfgfdfggd', 'admi4434544444453453453454n@test.com', '$2y$10$fTT8V3uwtKXzVmqjZFZGouCNF6No5YBikSumy2ix6.CqU0iGJsNV6', NULL, 'user', 1, '2026-01-26 11:24:28', NULL),
(22, 'sdffsdfsdfsdfs', 'petroliuk.taras@gmail.com', '$2y$10$yoqqkOgsWxOfyOPLdZbxXOhsUQzi2G00EV6I1bKuOQ10NL04tVLo6', NULL, 'user', 1, '2026-01-26 11:55:18', NULL),
(23, 'irusa', 'adsasdadsasd@gmail.com', '$2y$10$BA.TRVxwKkoGPiECPmQycO/UhT00ZWsWps4wvMjwxTLtEooD6nu1i', NULL, 'user', 1, '2026-01-27 18:39:43', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `videos`
--

CREATE TABLE `videos` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `poster` varchar(255) DEFAULT NULL,
  `hls` varchar(255) NOT NULL,
  `preview` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `duration` int UNSIGNED DEFAULT '0',
  `category_id` int UNSIGNED DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `videos`
--

INSERT INTO `videos` (`id`, `title`, `slug`, `description`, `poster`, `hls`, `preview`, `duration`, `category_id`, `status`, `created_at`) VALUES
(6, 'Test Video One', 'test-video-one', 'Це нова адаптація казки про Білосніжку. Дівчина на прекрасне ім’я Білосніжка чудово жила в палаці, поки при правлінні був її батько. Та все змінилося, коли його не стало. Мачуха була неймовірно сувора до дівчини та й до всього навколо. Новоспечена королева хотіла правити сильною рукою і вона без жалю приймала рішення щодо правління.  Білосніжка тим часом була добра та намагалася знайти справедливість для всіх.\n\nПроте навіть коли дівчина казала про це мачусі, то остання не вбачала в цьому абсолютно нічого, окрім непокори. Останньою краплею стале те, що дзеркало, яке знало все – сказало, що найвродливішою була не королева, а падчерка.Не очікуючи такої відповіді місце в серці королеви остаточно зайняло зло і вона забажала знову стати найвродливішою на світі, як раніше. А для цього вона вбачала лише один єдиний варіант – здихатися дівчинки. Прознавши про її лихий план Білосніжка втекла з палацу та королева не збиралася залишити це просто так.  ', '/uploads/posters/test1.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 360, NULL, 1, '2026-01-17 21:35:09'),
(7, 'Test Video Two', 'test-video-two', 'Це нова адаптація казки про Білосніжку. Дівчина на прекрасне ім’я Білосніжка чудово жила в палаці, поки при правлінні був її батько. Та все змінилося, коли його не стало. Мачуха була неймовірно сувора до дівчини та й до всього навколо. Новоспечена королева хотіла правити сильною рукою і вона без жалю приймала рішення щодо правління.  Білосніжка тим часом була добра та намагалася знайти справедливість для всіх.\n\nПроте навіть коли дівчина казала про це мачусі, то остання не вбачала в цьому абсолютно нічого, окрім непокори. Останньою краплею стале те, що дзеркало, яке знало все – сказало, що найвродливішою була не королева, а падчерка.Не очікуючи такої відповіді місце в серці королеви остаточно зайняло зло і вона забажала знову стати найвродливішою на світі, як раніше. А для цього вона вбачала лише один єдиний варіант – здихатися дівчинки. Прознавши про її лихий план Білосніжка втекла з палацу та королева не збиралася залишити це просто так.  ', '/uploads/posters/test2.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 420, NULL, 1, '2026-01-17 21:35:09'),
(8, 'Test Video Three', 'test-video-three', 'Це нова адаптація казки про Білосніжку. Дівчина на прекрасне ім’я Білосніжка чудово жила в палаці, поки при правлінні був її батько. Та все змінилося, коли його не стало. Мачуха була неймовірно сувора до дівчини та й до всього навколо. Новоспечена королева хотіла правити сильною рукою і вона без жалю приймала рішення щодо правління.  Білосніжка тим часом була добра та намагалася знайти справедливість для всіх.\n\nПроте навіть коли дівчина казала про це мачусі, то остання не вбачала в цьому абсолютно нічого, окрім непокори. Останньою краплею стале те, що дзеркало, яке знало все – сказало, що найвродливішою була не королева, а падчерка.Не очікуючи такої відповіді місце в серці королеви остаточно зайняло зло і вона забажала знову стати найвродливішою на світі, як раніше. А для цього вона вбачала лише один єдиний варіант – здихатися дівчинки. Прознавши про її лихий план Білосніжка втекла з палацу та королева не збиралася залишити це просто так.  ', '/uploads/posters/test3.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 6789, NULL, 1, '2026-01-17 21:38:53'),
(9, 'Test Video Four', 'test-video-four', 'Fourth test video description', '/uploads/posters/test4.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 480, NULL, 1, '2026-01-17 21:38:53'),
(10, 'Test Video Five', 'test-video-five', 'Fifth test video description', '/uploads/posters/test5.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 540, NULL, 1, '2026-01-17 21:38:53'),
(11, 'Test Video Six', 'test-video-six', 'Sixth test video description', '/uploads/posters/test6.jpg', '/uploads/videos/test5/master.m3u8', '/uploads/previews/video1.mp4', 600, NULL, 1, '2026-01-17 21:38:53');

-- --------------------------------------------------------

--
-- Структура таблицы `video_actors`
--

CREATE TABLE `video_actors` (
  `video_id` int UNSIGNED NOT NULL,
  `actor_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `video_actors`
--

INSERT INTO `video_actors` (`video_id`, `actor_id`) VALUES
(6, 1),
(7, 1),
(8, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `video_favorites`
--

CREATE TABLE `video_favorites` (
  `video_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `video_likes`
--

CREATE TABLE `video_likes` (
  `id` int UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `reaction` enum('like','dislike') NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `video_likes`
--

INSERT INTO `video_likes` (`id`, `video_id`, `user_id`, `reaction`, `created_at`) VALUES
(7, 8, 20, 'like', '2026-02-02 21:17:39'),
(17, 8, 15, 'like', '2026-02-03 20:04:32'),
(18, 8, 2, 'like', '2026-02-03 20:04:48');

-- --------------------------------------------------------

--
-- Структура таблицы `video_screenshots`
--

CREATE TABLE `video_screenshots` (
  `id` int UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort` int UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `video_screenshots`
--

INSERT INTO `video_screenshots` (`id`, `video_id`, `image`, `sort`) VALUES
(2, 8, 'video_8/1.jpg', 1),
(3, 8, 'video_8/2.jpg', 2),
(4, 8, 'video_8/3.jpg', 3),
(5, 8, 'video_8/4.jpg', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `video_studios`
--

CREATE TABLE `video_studios` (
  `video_id` int UNSIGNED NOT NULL,
  `studio_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `video_studios`
--

INSERT INTO `video_studios` (`video_id`, `studio_id`) VALUES
(8, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `video_views`
--

CREATE TABLE `video_views` (
  `id` bigint UNSIGNED NOT NULL,
  `video_id` int UNSIGNED NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `video_views`
--

INSERT INTO `video_views` (`id`, `video_id`, `ip`, `user_id`, `created_at`) VALUES
(76, 8, '37.52.17.117', NULL, '2026-01-18 00:35:46'),
(77, 8, '37.52.17.117', NULL, '2026-01-18 00:47:19'),
(78, 8, '37.52.17.117', NULL, '2026-01-18 00:49:38'),
(79, 10, '43.133.66.51', NULL, '2026-01-18 07:16:39'),
(80, 11, '43.163.104.54', NULL, '2026-01-18 07:25:59'),
(81, 7, '43.166.226.57', NULL, '2026-01-18 07:34:26'),
(82, 9, '170.106.113.159', NULL, '2026-01-18 08:13:23'),
(83, 8, '37.52.17.117', NULL, '2026-01-18 10:01:31'),
(84, 8, '37.52.17.117', NULL, '2026-01-18 10:05:10'),
(85, 6, '43.135.145.73', NULL, '2026-01-18 10:15:48'),
(86, 8, '49.51.36.179', NULL, '2026-01-18 10:33:10'),
(87, 8, '37.52.17.117', NULL, '2026-01-18 11:30:05'),
(88, 8, '91.234.25.197', NULL, '2026-02-02 16:55:10'),
(89, 9, '91.234.25.197', NULL, '2026-02-02 16:55:39'),
(90, 9, '43.153.47.201', NULL, '2026-02-02 17:00:45'),
(91, 6, '37.52.31.39', NULL, '2026-02-02 17:30:52'),
(92, 8, '37.52.31.39', NULL, '2026-02-02 17:31:10'),
(93, 10, '37.52.31.39', NULL, '2026-02-02 17:31:39'),
(94, 8, '43.131.32.36', NULL, '2026-02-02 17:42:19'),
(95, 8, '37.52.31.39', 20, '2026-02-02 21:17:27'),
(96, 8, '37.52.31.39', 16, '2026-02-02 21:27:30'),
(97, 8, '91.234.25.210', NULL, '2026-02-03 08:25:43'),
(98, 8, '2a02:2378:12ac:f87f:147e:3cdf:ddbd:d809', NULL, '2026-02-03 09:23:37'),
(99, 8, '2a02:2378:12a8:9009:64:1d68:c24e:e3e1', NULL, '2026-02-03 13:52:40'),
(100, 7, '91.234.25.210', NULL, '2026-02-03 14:16:58'),
(101, 6, '91.234.25.210', NULL, '2026-02-03 14:17:02'),
(102, 9, '91.234.25.210', NULL, '2026-02-03 14:17:08'),
(103, 8, '91.234.25.210', 19, '2026-02-03 16:49:02'),
(104, 8, '37.52.31.39', 15, '2026-02-03 19:40:29'),
(105, 8, '37.52.31.39', 8, '2026-02-03 20:04:10'),
(106, 8, '37.52.31.39', 2, '2026-02-03 20:04:47');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `actors`
--
ALTER TABLE `actors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `category_video`
--
ALTER TABLE `category_video`
  ADD PRIMARY KEY (`category_id`,`video_id`),
  ADD KEY `video_id` (`video_id`);

--
-- Индексы таблицы `collections`
--
ALTER TABLE `collections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `collection_videos`
--
ALTER TABLE `collection_videos`
  ADD PRIMARY KEY (`collection_id`,`video_id`),
  ADD KEY `video_id` (`video_id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `video_id` (`video_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Индексы таблицы `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `studios`
--
ALTER TABLE `studios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `category_id` (`category_id`);

--
-- Индексы таблицы `video_actors`
--
ALTER TABLE `video_actors`
  ADD PRIMARY KEY (`video_id`,`actor_id`),
  ADD KEY `actor_id` (`actor_id`);

--
-- Индексы таблицы `video_favorites`
--
ALTER TABLE `video_favorites`
  ADD PRIMARY KEY (`video_id`,`user_id`),
  ADD KEY `fk_fav_user` (`user_id`);

--
-- Индексы таблицы `video_likes`
--
ALTER TABLE `video_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_video_user` (`video_id`,`user_id`),
  ADD KEY `video_id` (`video_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `video_screenshots`
--
ALTER TABLE `video_screenshots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `video_id` (`video_id`);

--
-- Индексы таблицы `video_studios`
--
ALTER TABLE `video_studios`
  ADD PRIMARY KEY (`video_id`,`studio_id`),
  ADD KEY `studio_id` (`studio_id`);

--
-- Индексы таблицы `video_views`
--
ALTER TABLE `video_views`
  ADD PRIMARY KEY (`id`),
  ADD KEY `video_id` (`video_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `actors`
--
ALTER TABLE `actors`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `collections`
--
ALTER TABLE `collections`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `studios`
--
ALTER TABLE `studios`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `video_likes`
--
ALTER TABLE `video_likes`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `video_screenshots`
--
ALTER TABLE `video_screenshots`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `video_views`
--
ALTER TABLE `video_views`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `category_video`
--
ALTER TABLE `category_video`
  ADD CONSTRAINT `category_video_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_video_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `collection_videos`
--
ALTER TABLE `collection_videos`
  ADD CONSTRAINT `collection_videos_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `collection_videos_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `videos`
--
ALTER TABLE `videos`
  ADD CONSTRAINT `videos_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Ограничения внешнего ключа таблицы `video_actors`
--
ALTER TABLE `video_actors`
  ADD CONSTRAINT `video_actors_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `video_actors_ibfk_2` FOREIGN KEY (`actor_id`) REFERENCES `actors` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `video_favorites`
--
ALTER TABLE `video_favorites`
  ADD CONSTRAINT `fk_fav_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fav_video` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `video_screenshots`
--
ALTER TABLE `video_screenshots`
  ADD CONSTRAINT `fk_video_screenshots_video` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `video_studios`
--
ALTER TABLE `video_studios`
  ADD CONSTRAINT `video_studios_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `video_studios_ibfk_2` FOREIGN KEY (`studio_id`) REFERENCES `studios` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `video_views`
--
ALTER TABLE `video_views`
  ADD CONSTRAINT `video_views_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
