document.addEventListener('DOMContentLoaded', function () {

  // ================== GENDER FILTER ==================
  const genderSelect = document.getElementById('genderSelect');
  if (genderSelect) {
    genderSelect.addEventListener('change', function () {
      const gender = this.value;
      const basePath = window.location.pathname;

      if (gender) window.location.href = basePath + '?gender=' + gender;
      else window.location.href = basePath;
    });
  }

  // ================== VIDEO PREVIEW (hover, delay, JS video create/remove) ==================
  let previewVideo = null;
  let timer = null;
  const DELAY = 1200;

  document.addEventListener('mouseover', (e) => {
    const card = e.target.closest('.card-thumb[data-preview]');
    if (!card) return;
    if (timer || previewVideo) return;

    const progress = card.querySelector('.preview-progress');
    if (!progress) return;

    progress.style.display = 'block';
    progress.style.transition = 'none';
    progress.style.width = '0%';
    progress.offsetHeight;

    progress.style.transition = `width ${DELAY}ms ease-in-out`;
    progress.style.width = '100%';

    timer = setTimeout(() => {
      previewVideo = document.createElement('video');
      previewVideo.src = card.dataset.preview;
      previewVideo.muted = true;
      previewVideo.loop = true;
      previewVideo.autoplay = true;
      previewVideo.playsInline = true;

      previewVideo.style.position = 'absolute';
      previewVideo.style.inset = '0';
      previewVideo.style.width = '100%';
      previewVideo.style.height = '100%';
      previewVideo.style.objectFit = 'cover';

      previewVideo.addEventListener('playing', () => {
        progress.style.display = 'none';
      }, { once: true });

      card.appendChild(previewVideo);
      previewVideo.play().catch(() => {});
    }, DELAY);
  });

  document.addEventListener('mouseout', (e) => {
    const card = e.target.closest('.card-thumb');
    if (!card) return;

    clearTimeout(timer);
    timer = null;

    const progress = card.querySelector('.preview-progress');
    if (progress) {
      progress.style.display = 'none';
      progress.style.width = '0%';
    }

    if (previewVideo) {
      previewVideo.pause();
      previewVideo.remove();
      previewVideo = null;
    }
  });

  // ================== PASSWORD TOGGLE ==================
  function togglePasswordByInput(inputEl) {
    if (!inputEl) return;

    inputEl.type = (inputEl.type === 'password') ? 'text' : 'password';

    const eyeIcon = inputEl.nextElementSibling;
    if (eyeIcon) eyeIcon.classList.toggle('active');
  }

  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function () {
      const inputEl = this.previousElementSibling;
      togglePasswordByInput(inputEl);
    });
  });

  // ================== META BUTTON TOGGLE ==================
  document.querySelectorAll('.meta-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.dataset.action;
      const target = document.querySelector('.meta-expand-item[data-content="' + action + '"]');
      if (!target) return;

      const isActive = target.classList.contains('active');

      document.querySelectorAll('.meta-expand-item').forEach(item => item.classList.remove('active'));
      document.querySelectorAll('.meta-btn').forEach(button => button.classList.remove('active'));

      if (!isActive) {
        target.classList.add('active');
        btn.classList.add('active');
      }
    });
  });

  // ================== SCREENSHOTS LIGHTBOX + NAVIGATION ==================
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.querySelector('.lightbox-img');
  const lightboxClose = document.querySelector('.lightbox-close');
  const prevBtn = document.querySelector('.lightbox-nav.prev');
  const nextBtn = document.querySelector('.lightbox-nav.next');

  let screens = [];
  let currentIndex = 0;

  function showScreen(index) {
    if (!screens.length || !lightboxImg) return;

    if (index < 0) index = screens.length - 1;
    if (index >= screens.length) index = 0;

    currentIndex = index;
    lightboxImg.src = screens[currentIndex].src;
  }

  if (lightbox && lightboxImg) {
    // Відкриття (ОДИН обробник, без дубля)
    document.addEventListener('click', function (e) {
      const img = e.target.closest('.screens-grid img');
      if (!img) return;

      screens = Array.from(document.querySelectorAll('.screens-grid img'));
      currentIndex = screens.indexOf(img);
      if (currentIndex === -1) return;

      lightboxImg.src = screens[currentIndex].src;
      lightbox.classList.add('active');
    });

    // Закриття по ✕
    if (lightboxClose) {
      lightboxClose.addEventListener('click', function () {
        lightbox.classList.remove('active');
        lightboxImg.src = '';
      });
    }

    // Закриття по кліку на фон
    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) {
        lightbox.classList.remove('active');
        lightboxImg.src = '';
      }
    });

    // Prev / Next кнопки (з перевірками)
    if (prevBtn) prevBtn.addEventListener('click', () => showScreen(currentIndex - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => showScreen(currentIndex + 1));

    // Клавіатура (ESC + стрілки)
    document.addEventListener('keydown', function (e) {
      if (!lightbox.classList.contains('active')) return;

      if (e.key === 'Escape') {
        lightbox.classList.remove('active');
        lightboxImg.src = '';
      }
      if (e.key === 'ArrowLeft') showScreen(currentIndex - 1);
      if (e.key === 'ArrowRight') showScreen(currentIndex + 1);
    });
  }

  // ================== SHARE (select input text) ==================
  document.addEventListener('click', function (e) {
    const input = e.target.closest('.share-url, .share-bbcode');
    if (!input) return;

    input.select();
    input.setSelectionRange(0, 99999);
  });








document.addEventListener('click', function (e) {
  const btn = e.target.closest('.like-btn, .dislike-btn');
  if (!btn) return;

  const wrap = btn.closest('.meta-like-dislike');
  if (!wrap) return;

  const videoId = wrap.getAttribute('data-video-id');
  const reaction = btn.getAttribute('data-action'); // like | dislike

  const formData = new FormData();
  formData.append('video_id', videoId);
  formData.append('reaction', reaction);

  fetch('/ajax/video-reaction', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
if (!data.success) {
  if (data.message === 'Потрібно увійти') {
    openAuthModal();
    return;
  }
  return;
}

      const likeEl = wrap.querySelector('.like-count');
      const dislikeEl = wrap.querySelector('.dislike-count');
	    const totalEl = wrap.querySelector('.total-votes');

      if (likeEl) likeEl.textContent = data.likes;
      if (dislikeEl) dislikeEl.textContent = data.dislikes;
	  if (totalEl) totalEl.textContent = (Number(data.likes) + Number(data.dislikes));

      // (опційно) активний стан кнопок
      wrap.querySelectorAll('.like-btn, .dislike-btn').forEach(x => x.classList.remove('active'));
      if (data.status !== 'removed') btn.classList.add('active');
    })
    .catch(() => {});
});







function openAuthModal() {
  const m = document.getElementById('authModal');
  if (!m) return;
  m.classList.add('active');
  document.body.classList.add('modal-open');
}

function closeAuthModal() {
  const m = document.getElementById('authModal');
  if (!m) return;
  m.classList.remove('active');
  document.body.classList.remove('modal-open');
}

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-auth-close]')) closeAuthModal();
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeAuthModal();
});











  // ================== AUTOCOMPLETE SEARCH ==================
  const searchInput = document.getElementById('autocomplete');
  const suggestionsBox = document.getElementById('autocomplete-suggestions');
  let acController = null;

  if (searchInput && suggestionsBox) {
    searchInput.addEventListener('input', function () {
      const q = this.value.trim();

      if (q.length < 2) {
        suggestionsBox.style.display = 'none';
        suggestionsBox.innerHTML = '';
        return;
      }

      if (acController) acController.abort();
      acController = new AbortController();

      fetch('/search?ajax=true&query=' + encodeURIComponent(q), { signal: acController.signal })
        .then(r => r.json())
        .then(results => {
          suggestionsBox.innerHTML = '';

          if (Array.isArray(results) && results.length > 0) {
            suggestionsBox.style.display = 'block';

            const grouped = { "Відео": [], "Моделі": [], "Студії": [] };

            results.forEach(item => {
              if (item.type === 'video') grouped['Відео'].push(item);
              else if (item.type === 'actor') grouped['Моделі'].push(item);
              else if (item.type === 'studio') grouped['Студії'].push(item);
            });

            for (const group in grouped) {
              if (!grouped[group].length) continue;

              const title = document.createElement('div');
              title.classList.add('autocomplete-suggestion-title');
              title.textContent = group;
              suggestionsBox.appendChild(title);

              grouped[group].forEach(item => {
                const row = document.createElement('div');
                row.classList.add('autocomplete-suggestion');

                const link = document.createElement('a');
                link.href = item.url || '#';
                link.classList.add('link');

                const icon = item.icon ? item.icon : 'search';
                const name = item.name ? item.name : '';

                link.innerHTML = `<i class="fas fa-${icon}"></i>${name}`;

                row.appendChild(link);
                suggestionsBox.appendChild(row);
              });
            }
          } else {
            suggestionsBox.style.display = 'block';
            const no = document.createElement('div');
            no.classList.add('autocomplete-suggestion');
            no.textContent = 'Нічого не знайдено';
            suggestionsBox.appendChild(no);
          }
        })
        .catch(err => {
          if (err.name === 'AbortError') return;
          console.error('Error:', err);
          suggestionsBox.style.display = 'none';
          suggestionsBox.innerHTML = '';
        });
    });
  }

  // ================== REPORT FORM (AJAX) ==================
  const reportForm = document.querySelector('.report-form');
  const reportButton = document.querySelector('.send-report');

  if (reportForm && reportButton) {
    const successMessage = document.createElement('div');
    const errorMessage = document.createElement('div');

    successMessage.classList.add('report-message-success');
    errorMessage.classList.add('report-message-error');

    reportForm.appendChild(successMessage);
    reportForm.appendChild(errorMessage);

    reportButton.addEventListener('click', function () {
      const reasonEl = document.querySelector('.report-reason');
      const msgEl = document.querySelector('.report-message');

      const reason = reasonEl ? reasonEl.value : '';
      const message = msgEl ? msgEl.value : '';

      if (!reason || !message) {
        errorMessage.textContent = 'Будь ласка, виберіть причину та введіть текст.';
        errorMessage.style.display = 'block';
        successMessage.style.display = 'none';
        return;
      }

      const formData = new FormData();
      formData.append('reason', reason);
      formData.append('message', message);

      fetch('/ajax/submit_report.php', {
        method: 'POST',
        body: formData
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            successMessage.textContent = data.message;
            successMessage.style.display = 'block';
            errorMessage.style.display = 'none';

            reportForm.reset();

            setTimeout(() => location.reload(), 2000);
          } else {
            errorMessage.textContent = data.message;
            errorMessage.style.display = 'block';
            successMessage.style.display = 'none';
          }
        })
        .catch(error => {
          console.error('Помилка при відправці запиту:', error);
          errorMessage.textContent = 'Сталася помилка при відправці скарги. Спробуйте ще раз.';
          errorMessage.style.display = 'block';
          successMessage.style.display = 'none';
        });
    });
  }

});
