<div class="auth-page">

    <div class="auth-box">

        <h1 class="auth-title">Відновлення паролю</h1>
		<br />

        <!-- Виведення помилок -->
        <?php if (!empty($error)): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Якщо успішно, виводимо повідомлення -->
        <?php if (!empty($success)): ?>
            <div class="success-message">
                Інструкції надіслані на вашу пошту<br/>
				(якщо пошта існує)
            </div>
        <?php else: ?>

        <!-- Форма для введення email -->
        <form class="auth-form" method="post">

            <input type="text" name="email" placeholder="E-mail" required>

            <!-- CAPTCHA -->
            <div class="captcha-box">
                <label class="captcha-label">
                    Скільки буде <?= $captcha_a ?> + <?= $captcha_b ?> ?
                </label>
                <input type="text" name="captcha" placeholder="Ваша відповідь" required>
            </div>

            <button type="submit" class="auth-submit">
                Відновити
            </button>

        </form>

        <?php endif; ?>

        <div class="auth-footer">
            Згадали пароль? <a href="/login">Увійти</a>
        </div>

    </div>

</div>
