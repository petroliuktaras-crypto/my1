<main class="main">
    <div class="container">

        <!-- TOP BAR -->
        <div class="actors-top">

            <h1 class="page-title">Каталог акторів</h1>

            <!-- A-Z FILTER -->
<div class="actors-letters">
    <?php foreach (range('A','Z') as $char): ?>
        <a href="/actors/<?= $char ?><?= $gender ? '?gender='.$gender : '' ?>"
           class="<?= ($letter === $char) ? 'active' : '' ?>">
            <?= $char ?>
        </a>
    <?php endforeach; ?>
	<a href="/actors">ALL</a>
</div>



<!-- ================= GENDER SELECT ================= -->
<div class="actors-gender-filter">
    <select id="genderSelect">
        <option value="">Всі</option>
        <option value="female" <?= $gender === 'female' ? 'selected' : '' ?>>Жінки</option>
        <option value="male" <?= $gender === 'male' ? 'selected' : '' ?>>Чоловіки</option>
    </select>
</div>



        </div>

        <!-- ACTORS GRID -->
        <div class="actors-grid">

            <?php foreach ($actors as $a): ?>
                <a href="/actor/<?= $a['slug'] ?>" class="actor-card">

                    <img src="<?= $a['photo'] ?>" alt="<?= htmlspecialchars($a['name']) ?>">

                    <div class="actor-overlay">
                        <div class="actor-name"><?= htmlspecialchars($a['name']) ?></div>

                        <div class="actor-meta">
							<span><?= (int)$a['total_videos'] ?> відео</span>
                            <span><?= (int)$a['rating'] ?>%</span>
                        </div>
                    </div>

                </a>
            <?php endforeach; ?>

        </div>
		
		
		<?php if ($pages > 1): ?>
<div class="pagination">

    <?php for ($p = 1; $p <= $pages; $p++): ?>

        <?php
            // базовий URL
            $url = '/actors';

            // літера тільки в URL
            if (!empty($letter)) {
                $url .= '/' . $letter;
            }

            // GET параметри
            $query = [];

            if (!empty($gender)) {
                $query['gender'] = $gender;
            }

            if ($p > 1) {
                $query['page'] = $p;
            }

            if ($query) {
                $url .= '?' . http_build_query($query);
            }
        ?>

        <a href="<?= $url ?>" class="<?= ($p === $page) ? 'active' : '' ?>">
            <?= $p ?>
        </a>

    <?php endfor; ?>

</div>
<?php endif; ?>

		
		

    </div>
</main>
