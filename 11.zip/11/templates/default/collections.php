<main class="main">
    <div class="container">

<div class="collections-header">

    <h1 class="page-title">
        Добірки
    </h1>

    <div class="collections-sort">
        <a href="/collections?sort=new"
           class="<?= ($sort === 'new') ? 'active' : '' ?>">
            За новизною
        </a>

        <a href="/collections?sort=popular"
           class="<?= ($sort === 'popular') ? 'active' : '' ?>">
            За популярністю
        </a>
    </div>

</div>

        <div class="collections-grid-big">

            <?php foreach ($collections as $c): ?>
                <div class="collection-big-card">

                    <!-- IMAGE -->
                    <div class="collection-big-thumb">
                        <img src="<?= $c['poster'] ?>" alt="<?= htmlspecialchars($c['title']) ?>">
                    </div>

                    <!-- CONTENT -->
                    <div class="collection-big-info">

                        <div class="collection-big-count">
                            <?= (int)$c['total_videos'] ?>
                        </div>

                        <div class="collection-big-title">
                            <?= htmlspecialchars($c['title']) ?>
                        </div>

                        <a href="/collection/<?= $c['slug'] ?>" class="collection-big-btn">
                            ДЕТАЛЬНІШЕ
                        </a>

                    </div>

                </div>
            <?php endforeach; ?>

        </div>

    </div>
</main>
