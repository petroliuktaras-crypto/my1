<h1 class="page-title">Моє улюблене</h1>

<?php if (empty($videos)): ?>
    <div class="empty-state">
        Ви ще не додали жодного відео в улюблене ❤️
    </div>
<?php else: ?>

<div class="cards">
    <?php foreach ($videos as $v): ?>
        <div class="card">

            <div class="card-thumb" data-preview="<?= htmlspecialchars($v['preview']) ?>">
                <div class="preview-progress"></div>

                <img src="<?= htmlspecialchars($v['poster']) ?>" alt="">
                <div class="badge">❤️</div>

                <div class="card-overlay">
                    <span>⏱ <?= gmdate('i:s', (int)$v['duration']) ?></span>
                    <span>👁 <?= (int)$v['views'] ?></span>
                </div>
            </div>

            <div class="card-title">
                <a href="/video/<?= htmlspecialchars($v['slug']) ?>">
                    <?= htmlspecialchars($v['title']) ?>
                </a>
            </div>

        </div>
    <?php endforeach; ?>
</div>

<?php endif; ?>
