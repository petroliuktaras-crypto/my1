<main class="main">
    <div class="container">

<div class="collections-header">

    <h1 class="page-title">
        Студії
    </h1>

    <div class="collections-sort">
        <a href="/studios?sort=new"
           class="<?= ($sort === 'new') ? 'active' : '' ?>">
            За новизною
        </a>

        <a href="/studios?sort=popular"
           class="<?= ($sort === 'popular') ? 'active' : '' ?>">
            За популярністю
        </a>
    </div>

</div>

        <div class="collections-grid-big">

            <?php foreach ($studios as $s): ?>
                <div class="collection-big-card">

                    <!-- IMAGE -->
                    <div class="collection-big-thumb">
                        <img src="<?= $s['poster'] ?>" alt="<?= htmlspecialchars($s['title']) ?>">
                    </div>

                    <!-- CONTENT -->
                    <div class="collection-big-info">

                        <div class="collection-big-count">
                            <?= (int)$s['total_videos'] ?>
                        </div>

                        <div class="collection-big-title">
                            <?= htmlspecialchars($s['title']) ?>
                        </div>

                        <a href="/studio/<?= $s['slug'] ?>" class="collection-big-btn">
                            ДЕТАЛЬНІШЕ
                        </a>

                    </div>

                </div>
            <?php endforeach; ?>

        </div>
    </div>
</main>