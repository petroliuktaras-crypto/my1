<main class="main">
<div class="container">
    <div class="main-header">
         <h1 class="page-title">Нове відео</h1>

        <div class="tabs">
            <a href="/?filter=new" class="tab active">Новые</a>
            <a href="/?filter=best" class="tab">Лучшее</a>
            <a href="/?filter=views" class="tab">Просматриваемое</a>
        </div>
    </div>

<div class="cards">
<?php foreach ($videos as $v): ?>
    <div class="card">

        <!-- POSTER -->
        <div class="card-thumb" data-preview="<?= $v['preview'] ?>">
            <div class="preview-progress"></div>

            <img src="<?= $v['poster'] ?>" alt="">
            <div class="badge">Новые</div>

            <div class="card-overlay">
                <span>⏱ <?= gmdate('i:s', $v['duration']) ?></span>
                <span>👁 <?= (int)$v['views'] ?></span>
                <span>👍 85%</span>
            </div>
        </div>

        <!-- TITLE -->
        <div class="card-title">
            <a href="/video/<?= $v['slug'] ?>">
                <?= htmlspecialchars($v['title']) ?>
            </a>
        </div>

    </div>
<?php endforeach; ?>
</div>

 </div>
</main>