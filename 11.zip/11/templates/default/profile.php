<div class="profile-page">
    <h1>Профіль користувача</h1>
    <p>Привіт, <?php echo htmlspecialchars($user); ?>!</p>
</div>
<form method="POST">
    <button type="submit" name="logout">Вийти</button>
</form>