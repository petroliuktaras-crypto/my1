<div class="auth-page">
    <div class="auth-box">
        <?php if ($greeting): ?>
            <h1 class="auth-title"><?php echo $greeting; ?></h1>
        <?php else: ?>
            <h1 class="auth-title">Авторизація</h1>
        <?php endif; ?>

        <p class="auth-subtitle">Вітаємо вас на нашому сайті</p>

        <?php if ($error): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>

        <?php if (!$greeting): ?>
            <form class="auth-form" method="POST">
                <input type="email" name="email" placeholder="Пошта" required>
                <div class="auth-password">
                    <input type="password" id="password" name="password" placeholder="Пароль" required>
                    <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                </div>
                <button type="submit" class="auth-submit">Вхід</button>
            </form>
        <?php endif; ?>

        <div class="auth-footer">
            <div>
                Ще не зареєстровані?
                <a href="/register">Реєстрація</a>
            </div>
            <div>
                <a href="/forgot">Забули пароль?</a>
            </div>
        </div>
    </div>
</div>
