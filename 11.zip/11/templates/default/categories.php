<main class="main">
    <div class="container">

        <h1 class="page-title">Категорії</h1>

        <div class="categories-grid">

            <?php foreach ($categories as $cat): ?>
                <a href="/category/<?= $cat['slug'] ?>" class="category-row">

                    <span class="category-title">
                        <?= htmlspecialchars($cat['title']) ?>
                    </span>

                    <span class="category-dots"></span>

                    <span class="category-count">
                        <?= (int)$cat['total'] ?>
                    </span>

                </a>
            <?php endforeach; ?>

        </div>

    </div>
</main>
