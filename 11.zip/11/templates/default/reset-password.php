<div class="auth-page">
    <div class="auth-box">
        <h1 class="auth-title">Відновлення паролю</h1>
          <br />
        <?php if (!empty($error)): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success-message">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php else: ?>

        <form class="auth-form" method="post">
            			    <div class="auth-password">
                    <input type="password" id="new_password" name="new_password" placeholder="Новий пароль" required>
                    <span class="toggle-password" onclick="togglePassword('new_password')">👁</span>
                </div>

                <div class="auth-password">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Повторіть пароль" required>
                    <span class="toggle-password" onclick="togglePassword('confirm_password')">👁</span>
                </div>

            <div class="captcha-box">
                <label class="captcha-label">
                    Скільки буде <?= (int)$captcha_a ?> + <?= (int)$captcha_b ?> ?
                </label>
                <input type="text" name="captcha" placeholder="Ваша відповідь" required>
            </div>

            <button type="submit" class="auth-submit">
                Відновити
            </button>
        </form>

        <?php endif; ?>

        <div class="auth-footer">
            <a href="/login">Увійти</a>
        </div>
    </div>
</div>
