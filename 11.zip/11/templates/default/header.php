<!doctype html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Video Site</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/templates/default/css/style.css">
	<script src="/templates/default/js/main.js"></script>

</head>
<body>
<header class="header">
<div class="header-left">
    <a href="/" class="<?= $current === '' ? 'active' : '' ?>">Всі відео</a>
    <a href="/categories" class="<?= $current === 'categories' ? 'active' : '' ?>">Категорії</a>
    <a href="/actors" class="<?= $current === 'actors' ? 'active' : '' ?>">Актори</a>
    <a href="/collections" class="<?= $current === 'collections' ? 'active' : '' ?>">Колекції</a>
    <a href="/studios" class="<?= $current === 'studios' ? 'active' : '' ?>">Студії</a>
</div>

    <div class="header-center">LOGO</div>

    <div class="header-right">
<!-- Пошукова форма -->
<div class="block-search open">
  <form id="search_form" action="/search" method="get" class="holder-form">
    <div class="box-input search-text">
	<svg class="search-icon" viewBox="0 0 24 24">
        <path fill="currentColor" d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.71.71l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/>
    </svg>
      <input type="text" name="query" class="search-input" placeholder="Поиск" id="autocomplete" autocomplete="off">

    </div>
  </form>

  <div id="autocomplete-suggestions" class="serach-info-autocomplete" style="display:none;"></div>
</div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="/profile" class="auth-btn <?= $current === 'profile' ? 'active' : '' ?>">
			<svg viewBox="0 0 24 24"><path fill="currentColor"
              d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5z"/>
          </svg>
          <span><?php echo htmlspecialchars($_SESSION['login']); ?></span>

		</a>
		<!-- Перехід на профіль -->
    <?php else: ?>
        <a href="/login" class="auth-btn <?= $current === 'login' ? 'active' : '' ?>">
		
		    <svg viewBox="0 0 24 24">
        <path fill="currentColor"
              d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5z"/>
          </svg>
          <span>Вхід</span>
		
		</a> 
    <?php endif; ?>

    </div>
</header>
