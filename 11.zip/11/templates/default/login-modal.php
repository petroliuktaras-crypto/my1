<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>

       <link rel="stylesheet" href="/templates/default/css/style.css">

  <style>
    body{ margin:0; padding:0; background:transparent; font-family: Arial, sans-serif; }
    .auth-page{ padding: 0; }
    .auth-box{ background: transparent; box-shadow:none; padding: 0; }
  </style>
</head>
<body>

<div class="auth-page">
    <div class="auth-box">
        <h1 class="auth-title">Авторизація</h1>

        <p class="auth-subtitle">Вітаємо вас на нашому сайті</p>

        <?php if (!empty($error)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form class="auth-form" method="POST" action="/login?modal=1">
            <input type="email" name="email" placeholder="Пошта" required>

            <div class="auth-password">
                <input type="password" id="password" name="password" placeholder="Пароль" required>
                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
            </div>

            <button type="submit" class="auth-submit">Вхід</button>
        </form>

        <div class="auth-footer">
            <div>
                Ще не зареєстровані?
                <a href="/register" target="_parent">Реєстрація</a>
            </div>
            <div>
                <a href="/forgot" target="_parent">Забули пароль?</a>
            </div>
        </div>
    </div>
</div>

<script>
  // простий toggle пароля всередині iframe
  function togglePassword(id) {
    var el = document.getElementById(id);
    el.type = (el.type === 'password') ? 'text' : 'password';
  }
</script>

</body>
</html>
