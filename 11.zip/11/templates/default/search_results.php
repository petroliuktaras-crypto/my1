<div class="container">
<div class="search-title">
    <div class="search-title-head">
        Результати пошуку по запиту:
        <strong><?= htmlspecialchars($query) ?></strong>
    </div>

    <div class="counts">
        <?php if (!empty($videoCount)): ?>
            <span>Відео: <?= $videoCount ?></span>
        <?php endif; ?>

        <?php if (!empty($studioCount)): ?>
            <span>Студії: <?= $studioCount ?></span>
        <?php endif; ?>

        <?php if (!empty($actorCount)): ?>
            <span>Актори: <?= $actorCount ?></span>
        <?php endif; ?>

        <?php if (empty($videoCount) && empty($studioCount) && empty($actorCount)): ?>
            <span>Нічого не знайдено</span>
        <?php endif; ?>
    </div>

</div>
<?php if (!empty($results)): ?>
    <div class="search-results">
        <!-- Відображення відео -->
        <?php
        $videos = array_filter($results, function ($result) {
            return $result['type'] === 'video';
        });
        if (!empty($videos)): ?>
		    <h2 class="page-title">Відео</h2>
            <div class="cards">
                    <?php foreach ($videos as $video): ?>
                        <div class="card">
		<!-- POSTER -->
        <div class="card-thumb" data-preview="<?= $video['preview'] ?>">
            <div class="preview-progress"></div>

            <img src="<?= $video['poster'] ?>" alt="">
            <div class="badge">Новые</div>

            <div class="card-overlay">
                <span>⏱ <?= gmdate('i:s', $video['duration']) ?></span>
                <span>👁 <?= (int)$video['views'] ?></span>
                <span>👍 85%</span>
            </div>
        </div>

        <!-- TITLE -->
        <div class="card-title">
            <a href="<?= $video['url'] ?>">
                <?= htmlspecialchars($video['name']) ?>
            </a>
        </div>

   </div>
<?php endforeach; ?>
              
    </div>
<?php endif; ?>

        <!-- Відображення акторів -->
        <?php
        $actors = array_filter($results, function ($result) {
            return $result['type'] === 'actor';
        });
        if (!empty($actors)): ?>
		 <h2 class="page-title">Актори</h2>
           <div class="actors-grid">
               
                    <?php foreach ($actors as $actor): ?>

						
						                <a href="<?= $actor['url'] ?>" class="actor-card">

                    <img src="<?= $actor['photo'] ?>" alt="<?= htmlspecialchars($actor['name']) ?>">

                    <div class="actor-overlay">
                        <div class="actor-name"><?= htmlspecialchars($actor['name']) ?></div>

                        <div class="actor-meta">
							<span><?= (int)$actor['video_count'] ?> відео</span>
                            <span><?= (int)$a['rating'] ?>%</span>
                        </div>
                    </div>

                </a>
						
						
                    <?php endforeach; ?>
                
            </div>
        <?php endif; ?>



        <!-- Відображення студій -->
        <?php
        $studios = array_filter($results, function ($result) {
            return $result['type'] === 'studio';
        });
        if (!empty($studios)): ?>
		 <h2 class="page-title">Студії</h2>
             <div class="collections-grid-big">
               
 
                    <?php foreach ($studios as $studio): ?>
                         <div class="collection-big-card">
							                    <!-- IMAGE -->
                    <div class="collection-big-thumb">
                        <img src="<?= $studio['poster'] ?>" alt="<?= htmlspecialchars($studio['name']) ?>">
                    </div>

                    <!-- CONTENT -->
                    <div class="collection-big-info">

                        <div class="collection-big-count">
                            <?= (int)$studio['video_count'] ?>
                        </div>

                        <div class="collection-big-title">
                            <?= htmlspecialchars($studio['name']) ?>
                        </div>

                        <a href="<?= $studio['url'] ?>" class="collection-big-btn">
                            ДЕТАЛЬНІШЕ
                        </a>

                    </div>
                        </div>
                    <?php endforeach; ?>
               
            </div>
        <?php endif; ?>
    </div>
<?php else: ?>
 <div class="container">

    <div style="
        min-height: 60vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
    ">
        <div>
            <h1 style="font-size: 96px; margin: 0; color: #ff2d55;">Тут пусто...</h1>

            <p style="font-size: 20px; margin: 20px 0; color: #666;">
                

Новостей по данному запросу не найдено. 
            </p>

            <a href="/" style="
                display: inline-block;
                padding: 12px 28px;
                border-radius: 14px;
                background: #ff2d55;
                color: #fff;
                font-size: 16px;
            ">
                На головну
            </a>
        </div>
    </div>

</div>

<?php endif; ?>
</div>