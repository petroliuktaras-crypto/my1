<main class="main">
<div class="container">

    <h1 class="page-title"><?= htmlspecialchars($studio['title']) ?> ( <?= $totalVideos ?> відео)</h1> 

    <div class="cards">
        <?php foreach ($videos as $v): ?>
<div class="card">

    
        <!-- POSTER -->
        <div class="card-thumb" data-preview="<?= $v['preview'] ?>">
            <div class="preview-progress"></div>

            <img src="<?= $v['poster'] ?>" alt="">
            <div class="badge">Новые</div>

            <div class="card-overlay">
                <span>⏱ <?= gmdate('i:s', $v['duration']) ?></span>
                <span>👁 <?= (int)$v['views'] ?></span>
                <span>👍 85%</span>
            </div>
        </div>

    <!-- TITLE З ЛІНКОЮ -->
    <div class="card-title">
        <a href="/video/<?= $v['slug'] ?>">
            <?= htmlspecialchars($v['title']) ?>
        </a>
    </div>

</div>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="/studio/<?= $studio['slug'] ?>?page=<?= $i ?>"
                   class="<?= $i === $page ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

</div>
</main>
