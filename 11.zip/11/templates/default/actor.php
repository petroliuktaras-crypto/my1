<main class="main">
<div class="container">

    <!-- ================= ACTOR HEADER ================= -->
    <section class="actor-header">

        <div class="actor-photo">
            <img src="<?= $actor['photo'] ?>" alt="<?= htmlspecialchars($actor['name']) ?>">
        </div>

        <div class="actor-info">
            <h1><?= htmlspecialchars($actor['name']) ?></h1>

            <?php if ($actor['birthdate']): ?>
                <div class="actor-birth">
                    <?= date('d.m.Y', strtotime($actor['birthdate'])) ?>
                </div>
            <?php endif; ?>

            <?php if ($actor['bio']): ?>
                <div class="actor-bio">
                    <?= nl2br(htmlspecialchars($actor['bio'])) ?>
                </div>
            <?php endif; ?>
        </div>

    </section>
<div class="clear"></div>
    <!-- ================= ACTOR VIDEOS ================= -->
<!-- ================= ACTOR VIDEOS ================= -->
<section class="actor-section">

    <h2 class="actor-section-title">Відео з актором</h2>

    <div class="cards">
        <?php foreach ($videos as $v): ?>
<div class="card">

    <!-- ПОСТЕР БЕЗ ЛІНКУ -->
        <!-- POSTER -->
        <div class="card-thumb" data-preview="<?= $v['preview'] ?>">
            <div class="preview-progress"></div>

            <img src="<?= $v['poster'] ?>" alt="">
            <div class="badge">Новые</div>

            <div class="card-overlay">
                <span>⏱ <?= gmdate('i:s', $v['duration']) ?></span>
                <span>👁 <?= (int)$v['views'] ?></span>
                <span>👍 85%</span>
            </div>
        </div>

    <!-- TITLE З ЛІНКОЮ -->
    <div class="card-title">
        <a href="/video/<?= $v['slug'] ?>">
            <?= htmlspecialchars($v['title']) ?>
        </a>
    </div>

</div>
        <?php endforeach; ?>
    </div>

</section>

</div>
</main>
