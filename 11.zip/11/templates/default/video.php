<?php
// $video
// $actors
// $studios
// $collections
// $comments
// $recommended

?>

<div class="video-page">

    <!-- ================= LEFT COLUMN ================= -->
    <div class="video-main">



        <!-- PLAYER -->
        <div class="video-player">
            <iframe
                src="/player.php?token=<?= urlencode($token) ?>"
                frameborder="0"
                allowfullscreen
                width="100%"
                height="100%">
            </iframe>
        </div>

        <!-- ===== UNDER PLAYER ===== -->
<div class="video-meta-block">

    <!-- ===== ВЕРХ ===== -->
    <div class="video-meta-top">

<div class="meta-like-dislike" data-video-id="<?= (int)$video['id'] ?>">
    <div class="like-btn" data-action="like">
        <i class="fas fa-thumbs-up like-icon"></i>
    </div>

    <div class="dislike-btn" data-action="dislike">
        <i class="fas fa-thumbs-down dislike-icon"></i>
    </div>

    <div class="status-message">
        <span class="like-count"><?= (int)$likeCount ?></span> Лайків /
        <span class="dislike-count"><?= (int)$dislikeCount ?></span> Дізлайків
        <b>(<span class="total-votes"><?= (int)$totalVotes ?></span>)</b>
    </div>
</div>


        <div class="meta-info">
            <div class="meta-item">
                <svg viewBox="0 0 24 24"><path d="M12 5c-5.5 0-9.5 5-9.5 7s4 7 9.5 7 9.5-5 9.5-7-4-7-9.5-7zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/></svg>
                <span><?= (int)$viewsCount ?></span>
            </div>
            <div class="meta-item">
                <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 11h-5V11h3V6h2z"/></svg>
                <span>01:45:12</span>
            </div>
            <div class="meta-item">
                <span>+ Улюблене</span>
            </div>
        </div>

    </div>

    <!-- ===== НИЗ ===== -->
<div class="video-meta-bottom">

    <!-- РЯДОК -->
    <div class="meta-row">

<!-- Перевіряємо, чи є категорія -->
<?php if (!empty($category)): ?>
    <div class="meta-categories">
        <strong>Категорія:</strong>
        <!-- Виводимо категорію як посилання -->
        <a href="/category/<?= htmlspecialchars($category['slug']) ?>" class="meta-cat">
            <?= htmlspecialchars($category['title']) ?>
        </a>
    </div>
<?php else: ?>
    <!-- Якщо категорії немає, виводимо текст -->
    <div class="meta-categories">
        <strong>Категорія:</strong>
        <span>Категорія не вказана</span>
    </div>
<?php endif; ?>

        <div class="meta-actions">
            <div class="meta-btn" data-action="screens">Скріншоти</div>
            <div class="meta-btn" data-action="share">Поділитися</div>
            <div class="meta-btn" data-action="report">Поскаржитись</div>
        </div>

    </div>

    <!-- ↓↓↓ ОСЬ ТУТ ↓↓↓ -->
    <!-- БЛОК, ЯКИЙ РОСТЕ ВНИЗ -->
    <div class="meta-expand">

<div class="meta-expand-item" data-content="screens">
    <?php if (!empty($screenshots)): ?>
        <div class="screens-grid">
            <?php foreach ($screenshots as $img): ?>
                <img src="/uploads/screenshots/<?= htmlspecialchars($img) ?>" alt="">
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty">Скріншоти відсутні</div>
    <?php endif; ?>
</div>


<div class="meta-expand-item" data-content="share">

    <div class="share-field">
        <label>Посилання на відео</label>
        <input type="text" class="share-url" readonly
               value="<?= htmlspecialchars('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) ?>">
    </div>

    <div class="share-field">
        <label>BBCode</label>
        <input type="text" class="share-bbcode" readonly
               value="[url=<?= htmlspecialchars('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) ?>]<?= htmlspecialchars($video['title']) ?>[/url]">
    </div>

</div>


<div class="meta-expand-item" data-content="report">
<form class="report-form">
    <div class="form-group">
        <label for="report-reason">Оберіть причину</label>
        <select id="report-reason" class="report-reason">
            <option value="">Оберіть причину</option>
            <option value="Неправильний контент">Неправильний контент</option>
            <option value="Порушення правил">Порушення правил</option>
            <option value="Інші причини">Інші причини</option>
        </select>
    </div>

    <div class="form-group">
        <label for="report-message">Ваше повідомлення</label>
        <textarea id="report-message" class="report-message" placeholder="Опишіть проблему..."></textarea>
    </div>

    <button type="button" class="send-report">Надіслати</button>
</form>

</div>


    </div>

</div>


</div>



        <!-- ===== TITLE + DESC ===== -->
        <div class="video-info">
            <h1 class="video-title"><?= htmlspecialchars($video['title']) ?></h1>
            <div class="video-desc">
                <?= nl2br(htmlspecialchars($video['description'])) ?>
            </div>
        </div>

        <!-- ===== COMMENTS ===== -->
        <div class="comments">

            <h3>Залиште коментарій:</h3>

            <div class="comment-form">
                <input type="text" placeholder="Введіть нікнейм..">
                <textarea placeholder="Ваш коментар"></textarea>
                <button>Відправити</button>
            </div>

            <div class="comments-list">
                <?php foreach ($comments as $c): ?>
                    <div class="comment">
                        <img class="avatar" src="<?= $c['avatar'] ?: '/uploads/avatars/default.png' ?>">

                        <div class="comment-body">
                            <div class="comment-head">
                                <span class="username"><?= htmlspecialchars($c['login']) ?></span>
                                <span class="arrow">▼</span>
                            </div>

                            <div class="comment-text">
                                <?= nl2br(htmlspecialchars($c['message'])) ?>
                            </div>

                            <div class="comment-footer">
                                <span class="time"><?= $c['created_at'] ?></span>
                                <a href="#">Ответить</a>
                            </div>
                        </div>

                        <div class="comment-like">
                            <span><?= (int)$c['likes'] ?></span> ❤️
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>

        <!-- ===== RECOMMENDED ===== -->
        <?php if (!empty($recommended)): ?>
        <div class="video-related">
            <h2>Рекомендовані відео</h2>

            <div class="cards">
                <?php foreach ($recommended as $v): ?>
                    <div class="card">

        <!-- POSTER -->
        <div class="card-thumb" data-preview="<?= $v['preview'] ?>">
            <div class="preview-progress"></div>

            <img src="<?= $v['poster'] ?>" alt="">
            <div class="badge">Новые</div>

            <div class="card-overlay">
                <span>⏱ <?= gmdate('i:s', $v['duration']) ?></span>
                <span>👁 <?= (int)$v['views'] ?></span>
                <span>👍 85%</span>
            </div>
        </div>

                        <div class="card-title">
                            <a href="/video/<?= htmlspecialchars($v['slug']) ?>">
                                <?= htmlspecialchars($v['title']) ?>
                            </a>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <!-- ================= RIGHT SIDEBAR ================= -->
    <aside class="video-sidebar">

        <!-- ACTORS -->
        <?php if (!empty($actors)): ?>
        <div class="sidebar-box actors-box">
		<h3>Актори</h3>
            <?php foreach ($actors as $actor): ?>
                <a href="/actor/<?= htmlspecialchars($actor['slug']) ?>" class="actor-item">
                    <img src="<?= htmlspecialchars($actor['photo']) ?>">
                    <div class="actor-name"><?= htmlspecialchars($actor['name']) ?></div>
                </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- STUDIOS -->
        <?php if (!empty($studios)): ?>
        <div class="sidebar-box box-null">
            <h3>Студії</h3>

            <?php foreach ($studios as $studio): ?>
                <a href="/studio/<?= htmlspecialchars($studio['slug']) ?>" class="studio-item">
                    <div class="studio-thumb">
                        <img src="<?= htmlspecialchars($studio['poster']) ?>">
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- COLLECTIONS -->
        <?php if (!empty($collections)): ?>
        <div class="sidebar-box">
            <h3>Колекції</h3>

            <div class="collections-tags">
    <?php foreach ($collections as $col): ?>
        <a href="/collection/<?= htmlspecialchars($col['slug']) ?>" class="collection-tag">
            #<?= htmlspecialchars($col['title']) ?>
        </a>
    <?php endforeach; ?>
</div>
        </div>
        <?php endif; ?>
		
		
		
<?php if (!empty($videosWithActors)): ?>
    <div class="sidebar-box box-null">

         <h3>Відео з акторами</h3>

        <div class="cards cards-one-column">
            <?php foreach ($videosWithActors as $v): ?>
                <div class="card">

                    <div class="card-thumb" data-preview="<?=($v['preview']) ?>">
                        <div class="preview-progress"></div>

                        <img src="<?= htmlspecialchars($v['poster']) ?>" alt="<?= htmlspecialchars($v['title']) ?>">
                        <div class="badge">Новые</div>

                        <div class="card-overlay">
                            <span>⏱ <?= gmdate('i:s', (int)$v['duration']) ?></span>
                            <span>👁 <?= (int)$v['views'] ?></span>
                            <span>👍 85%</span>
                        </div>
                    </div>

                    <div class="card-title">
                        <a href="/video/<?= htmlspecialchars($v['slug']) ?>">
                            <?= htmlspecialchars($v['title']) ?>
                        </a>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>

    </div>
<?php endif; ?>

		
		

    </aside>

</div>
<div id="lightbox" class="lightbox">
    <span class="lightbox-close">×</span>

    <span class="lightbox-nav prev">‹</span>
    <span class="lightbox-nav next">›</span>

    <img class="lightbox-img" src="" alt="">
</div>

