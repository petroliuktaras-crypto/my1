<div class="container">

    <div style="
        min-height: 60vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
    ">
        <div>
            <h1 style="font-size: 96px; margin: 0; color: #ff2d55;">404</h1>

            <p style="font-size: 20px; margin: 20px 0; color: #666;">
                Сторінку не знайдено
            </p>

            <a href="/" style="
                display: inline-block;
                padding: 12px 28px;
                border-radius: 14px;
                background: #ff2d55;
                color: #fff;
                font-size: 16px;
            ">
                На головну
            </a>
        </div>
    </div>

</div>
