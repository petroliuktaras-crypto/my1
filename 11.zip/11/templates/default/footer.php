<footer class="footer">
    <div class="logo">LOGO</div>

    <div class="pages">
        <a href="#">Сторінка 1</a>
        <a href="#">Сторінка 2</a>
        <a href="#">Сторінка 3</a>
        <a href="#">Сторінка 4</a>
        <a href="#">Сторінка 5</a>
    </div>
</footer>

<div class="auth-modal" id="authModal">
  <div class="auth-modal__overlay" data-auth-close></div>

  <div class="auth-modal__window" role="dialog" aria-modal="true" aria-label="Login">
    <button class="auth-modal__close" type="button" aria-label="Close" data-auth-close>✕</button>

    <div class="auth-modal__grid">
      <!-- LEFT PROMO -->
      <div class="auth-modal__left">
        <div class="auth-modal__brand">koduma</div>

        <div class="auth-modal__stat">
          <div class="auth-modal__stat-title">З нами вже</div>
          <div class="auth-modal__stat-num">262202</div>
          <div class="auth-modal__stat-sub">користувачів</div>
        </div>

        <div class="auth-modal__benefits-title">Увійди / Зареєструйся і зможеш:</div>

        <div class="auth-modal__benefits">
          <div class="auth-modal__benefit">🔥 Додавати відео в обране</div>
          <div class="auth-modal__benefit">💬 Коментувати та ставити реакції</div>
          <div class="auth-modal__benefit">⭐ Збирати колекції</div>
          <div class="auth-modal__benefit">⬇️ Завантажувати в HD</div>
        </div>

        <!-- декор (по бажанню) -->
        <div class="auth-modal__decor decor-1">🍓</div>
        <div class="auth-modal__decor decor-2">💗</div>
      </div>

      <!-- RIGHT FORM -->
      <div class="auth-modal__right">
        <div class="auth-modal__title">Вхід</div>
        <div class="auth-modal__line"></div>

        <!-- ✅ беремо готову сторінку /login у модалку -->
        <iframe
          class="auth-modal__frame"
          src="/login?modal=1"
          title="Login"
          loading="lazy"
        ></iframe>

        <div class="auth-modal__bottom">
          <a href="/register" class="auth-modal__link">Зареєструватися</a>
        </div>
      </div>
    </div>
  </div>
</div>


</body>
</html>
