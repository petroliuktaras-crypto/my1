<div class="auth-page">
    <div class="auth-box">
        <!-- Якщо реєстрація успішна, виводимо повідомлення -->
        <?php if (isset($success)): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php else: ?>

            <h1 class="auth-title">Реєстрація</h1>
            <p class="auth-subtitle">Вітаємо Вас на нашому сайті!</p>

                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>


            <!-- Форма реєстрації -->
            <form class="auth-form" method="POST">

                <input type="email" name="email" placeholder="Пошта" required>

                <input type="text" name="nickname" placeholder="Нікнейм" required>

                <div class="auth-password">
                    <input type="password" id="password" name="password" placeholder="Пароль" required>
                    <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                </div>

                <div class="auth-password">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Повторіть пароль" required>
                    <span class="toggle-password" onclick="togglePassword('confirm_password')">👁</span>
                </div>

                <label class="auth-checkbox">
                    <input type="checkbox" name="accept_terms" required>
                    <span>Погоджуюся з <a target="_blank" href="/rules">правилами користування</a> сайта</span>
                </label>

                <!-- CAPTCHA -->
                <div class="captcha-box">
                    <label class="captcha-label">
                        Скільки буде <?= (int)$captcha_a ?> + <?= (int)$captcha_b ?> ?
                    </label>
                    <input
                        type="text"
                        name="captcha"
                        placeholder="Ваша відповідь"
                        required
                    >
                </div>



                <button type="submit" class="auth-submit">
                    Зареєструватися
                </button>

            </form>

        <?php endif; ?>

        <div class="auth-footer">
            Вже є акаунт? <a href="/login">Вхід</a>
        </div>

    </div>
</div>

