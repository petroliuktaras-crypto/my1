<?php
header('Content-Type: text/html; charset=UTF-8');

session_start();

define('ROOT', __DIR__);

require ROOT.'/engine/config.php';
require ROOT.'/engine/db.php';
require ROOT.'/engine/functions.php';
require ROOT.'/engine/router.php';

