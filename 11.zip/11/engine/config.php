<?php

// 
if (!defined('BASE_URL')) {
    define('BASE_URL', 'https://koduma.xyz'); 
}

// Перевіряємо, чи вже визначено ці константи
if (!defined('DB_HOST')) {
    define('DB_HOST', 'fi606084.mysql.tools');
}

if (!defined('DB_NAME')) {
    define('DB_NAME', 'fi606084_taraska');
}

if (!defined('DB_USER')) {
    define('DB_USER', 'fi606084_taraska');
}

if (!defined('DB_PASS')) {
    define('DB_PASS', '~r7)aJ2tE7');
}

if (!defined('TEMPLATE')) {
    define('TEMPLATE', 'default');
}

if (!defined('ACTORS_PER_PAGE')) {
    define('ACTORS_PER_PAGE', 18);
}

if (!defined('PER_PAGE')) {
    define('PER_PAGE', 18);
}
