<?php
$uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$parts = explode('/', $uri);

$page = $parts[0] ?: 'home';
$slug = $parts[1] ?? null;


if ($slug !== null) {
    $_GET['slug'] = $slug;
}

switch ($page) {

    case 'home':
        require ROOT.'/controllers/home.php';
        break;

    case 'video':
        if (!$slug) abort404();
        require ROOT.'/controllers/video.php';
        break;

    case 'actor':
        if (!$slug) abort404();
        require ROOT.'/controllers/actor.php';
        break;
		
	case 'actors':
        require ROOT.'/controllers/actors.php';
        break;

    case 'categories':
        require ROOT.'/controllers/categories.php';
        break;

    case 'category':
        if (!$slug) abort404();
        require ROOT.'/controllers/category.php';
        break;

    case 'collections':
        require ROOT.'/controllers/collections.php';
        break;

    case 'collection':
        if (!$slug) abort404();
        require ROOT.'/controllers/collection.php';
        break;
		
	case 'studios':
        require ROOT.'/controllers/studios.php';
        break;

    case 'studio':
	    if (!$slug) abort404();
        require ROOT.'/controllers/studio.php';
        break;

    case 'profile':
        require ROOT.'/controllers/profile.php';
        break;
	
	case 'login':
    require ROOT.'/controllers/login.php';
    break;
	


case 'register':
    require ROOT.'/controllers/register.php';
    break;
	
	case 'forgot':
    require ROOT.'/controllers/forgot.php';
    break;
	
		case 'rules':
    require ROOT.'/controllers/rules.php';
    break;
	
			case 'search':
    require ROOT.'/controllers/search.php';
    break;

case 'reset-password':
    // Перевірка на наявність токену в параметрах GET
    if (!isset($_GET['token'])) {
        abort404();  // Якщо токен не передано, 404 помилка
    }
    $token = $_GET['token'];  // Отримуємо токен
    require ROOT.'/controllers/reset-password.php';  // Викликаємо контролер для скидання паролю
    break;


case 'ajax':
    require ROOT.'/controllers/ajax.php';
    break;





    default:
        abort404();
}