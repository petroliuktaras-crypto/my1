<?php
define('ROOT', __DIR__);

// 1️⃣ конфіг (DB_HOST, DB_NAME…)
require_once ROOT . '/engine/config.php';

// 2️⃣ підключення БД ($db = new PDO)
require_once ROOT . '/engine/db.php';

// 3️⃣ functions (db(), token, helpers)
require_once ROOT . '/engine/functions.php';


// === IFRAME PROTECTION ===
header("X-Frame-Options: SAMEORIGIN");
header("Content-Security-Policy: frame-ancestors 'self'");

$allowedHost = 'koduma.xyz';

if (empty($_SERVER['HTTP_REFERER'])) {
    http_response_code(403);
    exit('No referer');
}

$refHost = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);

if ($refHost !== $allowedHost && $refHost !== 'www.'.$allowedHost) {
    http_response_code(403);
    exit('Bad referer');
}


$token = $_GET['token'] ?? '';
$video_id = validatePlayerToken($token);

if (!$video_id) {
    http_response_code(403);
    exit('Access denied');
}

$stmt = db()->prepare("
    SELECT hls
    FROM videos
    WHERE id = ? AND status = 1
");
$stmt->execute([$video_id]);
$video = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$video) {
    http_response_code(404);
    exit('Video not found');
}

$hls = $video['hls'];
?>
<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css">
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
<script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>
<style>
html,body{margin:0;background:#000;height:100%}
video{width:100%;height:100%}
</style>
</head>
<body>

<video id="player" controls playsinline></video>

<script>
const video = document.getElementById('player');
const source = "<?= htmlspecialchars($hls, ENT_QUOTES) ?>";

let player;

if (Hls.isSupported()) {
    const hls = new Hls({
        autoStartLoad: true,
    });

    hls.loadSource(source);
    hls.attachMedia(video);

    hls.on(Hls.Events.MANIFEST_PARSED, function () {

        // список доступних якостей
        const qualities = hls.levels.map(level => level.height);

        player = new Plyr(video, {
            quality: {
                default: qualities[qualities.length - 1],
                options: qualities,
                forced: true,
                onChange: quality => {
                    const levelIndex = hls.levels.findIndex(
                        l => l.height === quality
                    );
                    hls.currentLevel = levelIndex;
                }
            }
        });
    });

} else if (video.canPlayType('application/vnd.apple.mpegurl')) {

    // Safari (native HLS)
    player = new Plyr(video);
    video.src = source;

} else {
    console.error('HLS not supported');
}
</script>


</body>
</html>
